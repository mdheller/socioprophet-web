# SocioProphet Web — Full UI Skeleton

- Run `VITE_MOCK=1 npm run dev` to explore pages with mock data.
- Wire real TriRPC procedures in `src/services/triRpc.ts`.
